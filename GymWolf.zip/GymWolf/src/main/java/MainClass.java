import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import java.util.concurrent.TimeUnit;

public class MainClass {
    static WebDriver driver;


        GymWolfMainPage gymWolfMainPage = PageFactory.initElements(driver, GymWolfMainPage.class);
        //gymWolfMainPage.startRegistration("test@test.te");
       // gymWolfMainPage.clickMainRegisterButton();
    }

