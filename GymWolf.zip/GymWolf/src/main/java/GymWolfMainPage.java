import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class GymWolfMainPage {
    private WebDriver driver;

    public GymWolfMainPage(WebDriver driver) {
        this.driver = driver;
    }
    private By registerButton = By.xpath("/html/body/div[1]/div[1]/div/div[1]/div/div[3]/ul/li[1]/a");
    private By signinButton = By.xpath("/html/body/div[1]/div[1]/div/div[1]/div/div[3]/ul/li[2]/a");
    private By emailInput = By.xpath("/html/body/div[1]/div[1]/div/div[3]/div[2]/form/div[1]/input");
    private By mainRegisterButton = By.xpath("/html/body/div[1]/div[1]/div/div[3]/div[2]/form/div[2]/button");

    public GymWolfMainPage clickRegister(){
        driver.findElement(registerButton).click();
        return this;
    }
    public GymWolfMainPage typeEmail(String email){
        driver.findElement(emailInput).sendKeys(email);
        return this;
    }
    public RegisterGeneralPage startRegistration(String email){
        this.typeEmail(email);
        return new RegisterGeneralPage(driver);
    }
    public RegisterGeneralPage clickMainRegisterButton(){
        driver.findElement(mainRegisterButton).click();
        return new RegisterGeneralPage(driver);
    }
}
